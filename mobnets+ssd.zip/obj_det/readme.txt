##########################
For capturing video by webcam
##########################
python objdet.py --prototxt MobileNetSSD_deploy.prototxt.txt --model MobileNetSSD_deploy.caffemodel --image None
#############################
For running detection on an image
#############################
python objdet.py --prototxt MobileNetSSD_deploy.prototxt.txt --model MobileNetSSD_deploy.caffemodel --image image_filename
